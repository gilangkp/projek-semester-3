import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CreateTransactionForm extends JInternalFrame {

	JPanel panel1, panel2, panel3, panel4;
	JLabel idTitle, menuid, nameTitle, menuname, menuTitle, cartTitle, totalTitle, totalPrice, quantityTitle;
	JSpinner qty;
	JButton add, update, remove, finish, cancel;

	Connect con = Connect.getConnection();
	JScrollPane scroll1;
	JScrollPane scroll2;
	JTable menu = new JTable();
	JTable cart = new JTable();
	DefaultTableModel dtm = new DefaultTableModel();

	Vector<Vector> data = new Vector<>();
	Vector<String> columnnames = new Vector<>();

	private void InitialFrame() {
		setTitle("Transaction");
		setSize(900, 600);
		setClosable(true);
		setResizable(true);
		setVisible(true);
	}

	void Form() {
		panel1 = new JPanel(new GridLayout(3, 3));
		panel2 = new JPanel(new FlowLayout());
		panel3 = new JPanel(new FlowLayout());

		idTitle = new JLabel("ID");
		menuid = new JLabel("");
		nameTitle = new JLabel("Name");
		menuTitle = new JLabel("Menu: ");
		cartTitle = new JLabel("Cart: ");
		qty = new JSpinner();
		totalTitle = new JLabel("Total: ");
		totalPrice = new JLabel("");

		add = new JButton("Add");
		update = new JButton("Update");
		remove = new JButton("Remove");
		finish = new JButton("Finish");
		cancel = new JButton("Cancel");

		panel1.add(idTitle);
		panel1.add(menuid);
		panel1.add(nameTitle);
		panel1.add(qty);
		panel1.add(add);
		panel1.add(update);
		panel1.add(remove);

		columnnames.add("ID");
		columnnames.add("Name");
		columnnames.add("Sell Price");
		columnnames.add("Price");
		columnnames.add("Quantity");

		dtm = new DefaultTableModel(data, columnnames);
		menu.setModel(dtm);
		cart.setModel(dtm);

		scroll1.setViewportView(menu);
		scroll2.setViewportView(cart);

		panel2.add(menuTitle);
		panel2.add(scroll1, BorderLayout.WEST);
		
		panel3.add(cartTitle);
		panel3.add(scroll2, BorderLayout.EAST);

		panel4.add(totalTitle);
		panel4.add(totalPrice);
		panel4.add(cancel);
		panel4.add(finish);
	}

	void readData() {
		String query = "SELECT * FROM menu";
		ResultSet rs = con.executeQuery(query);
		try {
			data.clear();
			while (rs.next()) {
				String menuid = rs.getString(1);
				String name = rs.getString(2);
				String sellPrice = rs.getString(3);
				String ingPrice = rs.getString(4);

				Vector<String> vec = new Vector();

				vec.add(menuid);
				vec.add(name);
				vec.add(sellPrice);
				vec.add(ingPrice);

				data.add(vec);
			}

			dtm.fireTableDataChanged();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
	}

	public CreateTransactionForm() {
		InitialFrame();
	}

	public static void main(String[] args) {
		new Main();
	}

}
