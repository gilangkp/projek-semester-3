import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

import javax.swing.*;
public class Main extends JFrame
{
	JPanel panel, paneltittle;
	JLabel tittle,email,password, test;
	JTextField txtemail;
	JPasswordField txtpass;
	JButton login;
	Connect con = Connect.getConnection();
	static String role;
	private void LoginPanel()
	{
		panel = new JPanel (new FlowLayout());
		paneltittle = new JPanel (new FlowLayout());
		tittle = new JLabel ("Amore POS");
		paneltittle.add(tittle);
		
		email = new JLabel ("Email: ");
		email.setPreferredSize(new Dimension(70, 25));
	    panel.add(email);
	    txtemail = new JTextField();
	    txtemail.setPreferredSize(new Dimension(220, 25));
	    panel.add(txtemail);
	    
	    password = new JLabel ("Password: ");
	    password.setPreferredSize(new Dimension(70, 25));
	    panel.add(password);
	    txtpass = new JPasswordField();
	    txtpass.setPreferredSize(new Dimension(220, 25));
	    panel.add(txtpass);

        login = new JButton("Login") ;
        panel.add(login);
        

		setFocusable(true);
		setSize(350,200);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		add(paneltittle, BorderLayout.NORTH);
	    add(panel, BorderLayout.CENTER);
	}

	public Main() 
	{
		LoginPanel();
		ActionLogin();
	}

	public static void main(String[] args) 
	{
		new Main();
	}
	private void ActionLogin()
	{
		String getEmail = txtemail.getText();
		String getPass = txtpass.getText();
		login.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent e) 
				{
					
						if (txtemail.getText().length() == 0 && txtpass.getText().length() == 0)
						{
							JOptionPane.showMessageDialog(login, "Email and Password cannot be Empty");
						}
						else 
						{
							try {
					           String sql = "SELECT * FROM users WHERE email='"+txtemail.getText()+"' AND password='"+txtpass.getText()+"'";
					           ResultSet rs = con.executeQuery(sql);
					            if(rs.next()){
					                if(txtemail.getText().equals(rs.getString("email")) && txtpass.getText().equals(rs.getString("password"))){
					                    JOptionPane.showMessageDialog(null,"Welcome " + rs.getString("fullname") );
					                    role = rs.getString("role");
					                    MainForm MF = new MainForm();
					                    setVisible(false);
					                    dispose();
					                   
					                }
					            }else
					                {
					                    JOptionPane.showMessageDialog(null, "Incorrect Email or Password");
					                }
					        } catch (SQLException E) 
							  {
					            JOptionPane.showMessageDialog(login, E.getMessage());
					          }
							
						}					
					
				}
			}
		);
	}

}

