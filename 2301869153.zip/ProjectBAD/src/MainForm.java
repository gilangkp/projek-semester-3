import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

import javax.swing.*;
public class MainForm extends JFrame
{
	Main login = new Main();
	String getRole = Main.role;
	
	JMenu Account, Transaction, Manage, Finance;
	JMenuItem Logout, CreateTr, Accounts, RMenu, ViewMR;
	JMenuBar menu;
	JDesktopPane dp;
	

	
	private void InitialFrame()
	{	
		setJMenuBar(menu);
		setFocusable(true);
		setFocusable(true);
        setSize(700,1000);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
	}
	private void MenuComponent()
	{
		Account = new JMenu("Account");
		Transaction = new JMenu("Transaction");
		Manage = new JMenu("Manage");
		Finance = new JMenu("Finance");
		
		Logout = new JMenuItem("Logout");
		CreateTr = new JMenuItem("Create Transaction");
		Accounts = new JMenuItem("Accounts");
		RMenu = new JMenuItem("RestaurantMenu");
		ViewMR = new JMenuItem("ViewMonthlyReport");
		
		menu = new JMenuBar();
		
		Account.add(Logout);
		menu.add(Account);
		
		if(getRole.equalsIgnoreCase("Cashier"))
		{
			menu.add(Transaction);
			Transaction.add(CreateTr);
		}
		else if(getRole.equalsIgnoreCase("Admin"))
		{
			menu.add(Manage);
			Manage.add(Accounts);
			Manage.add(RMenu);
		}
		else if(getRole.equalsIgnoreCase("Accountant"))
		{
			menu.add(Finance);
			Finance.add(ViewMR);
		}
	}
	private void ActionMenu()
	{
		Logout.addActionListener(new ActionListener()
		{
			JDesktopPane dp = new JDesktopPane();
			public void actionPerformed(ActionEvent e) 
			{
			    Main M = new Main();
                setVisible(false);
                dispose();
			}
		}
	);
			Accounts.addActionListener(new ActionListener()
			{
				JDesktopPane dp = new JDesktopPane();
				public void actionPerformed(ActionEvent e) 
				{
					ManageAccountForm MAF = new ManageAccountForm();
					dp.add(MAF);
					setContentPane(dp);
				}
			}
		);
			ViewMR.addActionListener(new ActionListener()
			{
				JDesktopPane dp = new JDesktopPane();
				public void actionPerformed(ActionEvent e) 
				{
					FinanceForm FF = new FinanceForm();
					dp.add(FF);
					setContentPane(dp);
				}
			}
		);
			CreateTr.addActionListener(new ActionListener()
			{
				JDesktopPane dp = new JDesktopPane();
				public void actionPerformed(ActionEvent e) 
				{
					ManageMenuForm MMF = new ManageMenuForm();
					dp.add(MMF);
					setContentPane(dp);
					MMF.setVisible(true);
				}
			}
		);
			RMenu.addActionListener(new ActionListener()
			{
				JDesktopPane dp = new JDesktopPane();
				public void actionPerformed(ActionEvent e) 
				{
					ManageMenuForm MAM = new ManageMenuForm();
					dp.add(MAM);
					setContentPane(dp);
					MAM.setVisible(true);
				}
			}
		);
	}
	public MainForm() 
	{
		MenuComponent();
		ActionMenu();
		InitialFrame();
	}
	public static void main(String[] args) {
		new Main();

	}


}

