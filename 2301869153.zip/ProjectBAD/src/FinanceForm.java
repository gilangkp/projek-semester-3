import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class FinanceForm extends JInternalFrame implements ActionListener{
	Connect con = Connect.getConnection();

	JScrollPane pane = new JScrollPane();
	JTable table = new JTable();
	DefaultTableModel dtm = new DefaultTableModel();
	Vector<Vector> data = new Vector<>();
	Vector<String> columnNames = new Vector<>();
	

	public FinanceForm() {
		columnNames.add("Transactionn ID");
		columnNames.add("Modal");
		columnNames.add("Earn");
		columnNames.add("Gain");
		
		dtm= new DefaultTableModel(data, columnNames);
		table.setModel(dtm);
		
		pane.setViewportView(table);
		
		initializePanel();
		initializeFrame(); 

	}
	JPanel pnlTop = new JPanel (new FlowLayout());
	JPanel pnl = new JPanel (new GridLayout(2,2));
	JPanel pnlmid = new JPanel (new GridLayout(2,2));	
	JPanel panelForm = new JPanel(new GridLayout(2,1));
	JLabel lblmonth = new JLabel ("Month:"), lblyear = new JLabel ("Year:");
	JTextField txtmonth = new JTextField();
	JTextField txtyear = new JTextField();
	JButton view = new JButton ("View");
	

	private void initializePanel() {
		panelForm.add(lblyear); 
		panelForm.add(lblmonth);
		panelForm.add(txtyear);
		panelForm.add(txtmonth);
		
		pnlTop.add(view);
		pnl.add(panelForm);
		pnlmid.add(pane);
		
		add(pnl, BorderLayout.NORTH);
		add(pnlmid, BorderLayout.CENTER);
		add(pnlTop, BorderLayout.EAST);
		
	}
	private void initializeFrame() {
		setTitle("Finance Report");
		setFocusable(true);
        setSize(500,500);
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setVisible(true);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == view) {
			String m = txtmonth.getText();
			String y = txtyear.getText();
			
			if (m.matches("[0-9]+") == false || y.matches("[0-9]+") == false) {
				JOptionPane.showMessageDialog(null, "Month and year must be a number!");
			}
			else {
				int month= Integer.parseInt(m);
				if (month < 1 || month > 12) {
					JOptionPane.showMessageDialog(null, "Month must be between 1-12 !");
				}
				else {
					try {
						String query = "SELECT transactiondetail.transactionid AS ID, SUM(transactiondetail.quantity*menu.ingredientprice) AS Modal , "
								+ "SUM(transactiondetail.quantity*menu.sellprice) AS Earn, SUM(transactiondetail.quantity*menu.sellprice) - "
								+ "SUM(transactiondetail.quantity*menu.ingredientprice) AS Gain FROM transactiondetail INNER JOIN transactionheader "
								+ "ON transactiondetail.transactionid = transactionheader.transactionid INNER JOIN menu ON transactiondetail.menuid "
								+ "= menu.menuid WHERE MONTH(transactionheader.transactiondate) = "+month+" AND YEAR(transactionheader.transactiondate) "
								+ "= "+y+" GROUP BY transactiondetail.transactionid";
						 con.executeQuery(query);
					
					} catch (Exception exception) {
						exception.printStackTrace();
					}
				}
				
				}
			}	
		}
	

	public static void main(String[] args) {
		new Main();

	}

}

