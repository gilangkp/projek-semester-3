import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Random;

public class ManageAccountForm extends JInternalFrame 
{
	JPanel panel1, panel2, panel3;
	JLabel id, getid, fullname, role, email, pass;
	JTextField txtfullname, txtemail, txtpass;
	JComboBox boxrole;
	JButton insert, update, delete;
	
	Connect con = Connect.getConnection();
	JScrollPane pane;
	JTable table = new JTable();
	DefaultTableModel dtm = new DefaultTableModel();
	
	Vector<Vector> data = new Vector<>();
	Vector<String> columnnames = new Vector<>();
	public ManageAccountForm() 
	{
		Form();
//		selectTabel();
		Action();
		InitialFrame();
	}
	public void Form()
	{
		String[] boxlist = {"", "Accountant", "Admin", "Cashier"};
		panel1 = new JPanel(new GridLayout(1, 1));
		panel2 = new JPanel(new GridLayout(4, 3));
		pane = new JScrollPane();
		panel3 = new  JPanel(new FlowLayout());
		
		fullname = new JLabel("Fullname:");
		id = new JLabel("ID");
		getid = new JLabel("");
		role = new JLabel("Role:");
		email = new JLabel("Email:");
		pass = new JLabel("Password:");
		
		txtfullname = new JTextField();
		boxrole = new JComboBox(boxlist);
		txtemail = new JTextField();
		txtpass = new JTextField();
		
		insert = new JButton("Insert");
		update = new JButton("Update");
		delete = new JButton("Delete");
		
		panel1.add(id);
		panel1.add(getid);
		panel2.add(fullname);
		panel2.add(txtfullname);
		panel2.add(insert);
		panel2.add(role);
		panel2.add(boxrole);
		panel2.add(update);
		panel2.add(email);
		panel2.add(txtemail);
		panel2.add(delete);
		panel2.add(pass);
		panel2.add(txtpass);
		
		columnnames.add("ID");
		columnnames.add("Fullname");
		columnnames.add("Role");
		columnnames.add("Email");
		columnnames.add("Password");
		
		dtm = new DefaultTableModel(data, columnnames);
		table.setModel(dtm);
		
		pane.setViewportView(table);
		panel3.add(pane);
		
		add(panel1, BorderLayout.NORTH);
	    add(panel2, BorderLayout.CENTER);
	    add(panel3, BorderLayout.SOUTH);
	    
		readData();
	}
	private void InitialFrame()
	{
		setTitle("Manage Account Menu");
		setSize(600,900);
		setClosable(true);
		setResizable(true);
		setVisible(true);
	}
//	public void selectTabel()
//	{
//		DefaultTableModel dtm = (DefaultTableModel)table.getModel();
//		String tblid = dtm.getValueAt(table.getSelectedRow(),0).toString();
//		String tblname = dtm.getValueAt(table.getSelectedRow(),1).toString();
//		String tblrole = dtm.getValueAt(table.getSelectedRow(),3).toString();
//		String tblemail = dtm.getValueAt(table.getSelectedRow(),4).toString();
//		String tblpassword = dtm.getValueAt(table.getSelectedRow(),5).toString();
//		getid.setText(tblid);
//		txtfullname.setText(tblname);
//		if(tblrole.equals("Admin"))
//		{
//			boxrole.setSelectedIndex(1);
//		}
//		if(tblrole.equals("Cashier"))
//		{
//			boxrole.setSelectedIndex(2);
//		}
//		if(tblrole.equals("Accountant"))
//		{
//			boxrole.setSelectedIndex(3);
//		}
//		txtemail.setText(tblemail);
//		txtpass.setText(tblpassword);
//	}
	void readData()
	{
		String query = "SELECT * FROM users";
		ResultSet rs = con.executeQuery(query);
		try
		{
			data.clear();
			while(rs.next())
			{
				String  id = rs.getString(1);
				String  fullname = rs.getString(2);
				String  role = rs.getString(3);
				String  email = rs.getString(4);
				String  password = rs.getString(5);
				
				Vector<String> vec = new Vector();
				
				vec.add(id);
				vec.add(fullname);
				vec.add(role);
				vec.add(email);
				vec.add(password);
				
				data.add(vec);
			}
			
			dtm.fireTableDataChanged();
		}
		catch(SQLException throwables)
		{
			throwables.printStackTrace();
		}
	}
	private void Action()
	{
		String getEmail = txtemail.getText();
		String getPass = txtpass.getText();
		insert.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent e) 
				{
					insertData();
				}
			}
		);
		delete.addActionListener(new ActionListener()
		{
		public void actionPerformed(ActionEvent e) 
		{
			deletedata();
		}
		
	}
);
		update.addActionListener(new ActionListener()
		{
		public void actionPerformed(ActionEvent e) 
		{
			updatedata();
		}
	}
);
	}
	void insertData()
	{
		String name = txtfullname.getText();
		String getRole = "";
		if(boxrole.getSelectedIndex() == 1)
		{
			getRole = "Admin";
		}
		else if(boxrole.getSelectedIndex() == 2)
		{
			getRole = "Cashier";
		}
		else if(boxrole.getSelectedIndex() == 3)
		{
			getRole = "Accountant";
		}
		String email = txtemail.getText();
		String password = txtpass.getText();
		String id = "";
		Random r = new Random();
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwwxyz0123456789";
        for(int i = 0; i<10; i++)
        {
        id += alphabet.charAt(r.nextInt(42));
        }
        
		if(name.length() == 0 || getRole.length() == 0 || email.length() == 0 || password.length() == 0 )
		{
			JOptionPane.showMessageDialog(null, "All Field must be Filled");
		}
		else
		{
			if(email.startsWith("@") == true || email.endsWith("@") == true || email.endsWith(".") || email.contains("@.") || email.contains(".@"))
			{
				JOptionPane.showMessageDialog(null, "Wrong email format!");
			}
			else
			{	
					if(data.contains(email))
					{
						JOptionPane.showMessageDialog(null, "Email already used!");
					}
					else
					{
						Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
						 
					    Matcher matcher = pattern.matcher(password);
						if(!matcher.matches())
						{
						JOptionPane.showMessageDialog(null, "Password must be Alphanumeric!");
						}
						else
						{
							String query = "INSERT INTO users(userid, fullname, role, email, password) VALUES ('"+id+"','"+name+"','"+getRole+"','"+email+"','"+password+"')";
							con.executeUpdate(query);
							readData();
						}
					}
			}
		}
		
	}
	void updatedata()
	{
		if(table.getSelectedRow() == 0)
		{
			JOptionPane.showMessageDialog(null, "please select data to be updated first");
		}
		else 
		{
			String getId = dtm.getValueAt(table.getSelectedRow(), 0).toString();
			{
				String name = txtfullname.getText();
				String getRole = "";
				if(boxrole.getSelectedIndex() == 1)
				{
					getRole = "Admin";
				}
				else if(boxrole.getSelectedIndex() == 2)
				{
					getRole = "Cashier";
				}
				else if(boxrole.getSelectedIndex() == 3)
				{
					getRole = "Accountant";
				}
				String email = txtemail.getText();
				String password = txtpass.getText();
				if(name.length() == 0 || getRole.length() == 0 || email.length() == 0 || password.length() == 0 )
				{
					JOptionPane.showMessageDialog(null, "All Field must be Filled");
				}
				else
				{
					if(email.startsWith("@") == true || email.endsWith("@") == true || email.endsWith(".") || email.contains("@.") || email.contains(".@"))
					{
						JOptionPane.showMessageDialog(null, "Wrong email format!");
					}
					else
					{	
							if(data.contains(email))
							{
								JOptionPane.showMessageDialog(null, "Email already used!");
							}
							else
							{
								Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
								 
							    Matcher matcher = pattern.matcher(password);
								if(!matcher.matches())
								{
								JOptionPane.showMessageDialog(null, "Password must be Alphanumeric!");
								}
								else
								{
									String query = "UPDATE users SET fullname ='"+name+"', role ='"+getRole+"', email = '"+email+"', password = '"+password+"'"
											+ "WHERE userid ='"+getId+"'";
									
									con.executeUpdate(query);
									readData();
								}
							}
					}
				}
				
			}
			
			
		}
	}
	void deletedata()
	{
		if(table.getSelectedRow() == 0)
		{
			JOptionPane.showMessageDialog(null, "please select data to be deleted first");
		}
		else 
		{
			String getId = dtm.getValueAt(table.getSelectedRow(), 0).toString();
			String query = "DELETE FROM users WHERE userid ='"+getId+"'";
			con.executeUpdate(query);
			readData();
		}
	}
	public static void main(String[] args) 
	{
		new Main();
	}
	
}
