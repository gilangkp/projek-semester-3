import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Random;


public class ManageMenuForm extends JInternalFrame 
{
	JPanel panel1, panel2, panel3;
	JLabel lid, lgetid, lname, lsp, lip;
	JTextField txtname, txtid, txtsp, txtip;
	JButton insert, update, delete;
	
	Connect con = Connect.getConnection();
	JScrollPane pane;
	JTable table = new JTable();
	DefaultTableModel dtm = new DefaultTableModel();
	
	Vector<Vector> data = new Vector<>();
	Vector<String> columnnames = new Vector<>();
	private void InitialFrame()
	{
		setTitle("Manage Account Menu");
		setSize(600,900);
		setClosable(true);
		setResizable(true);
		setVisible(true);
	}
	private void InitialComponent()
	{
		panel1 = new JPanel(new GridLayout(1, 1));
		panel2 = new JPanel(new GridLayout(3, 3));
		pane = new JScrollPane();
		panel3 = new  JPanel(new FlowLayout());
		
		lname = new JLabel("Name:");
		lid = new JLabel("ID");
		lgetid = new JLabel("");
		lsp = new JLabel("Sell Price:");
		lip = new JLabel("Indigrient Price:");
		
		txtname = new JTextField();
		txtsp = new JTextField();
		txtip = new JTextField();
		
		insert = new JButton("Insert");
		update = new JButton("Update");
		delete = new JButton("Delete");
		
		panel1.add(lid);
		panel1.add(lgetid);
		panel2.add(lname);
		panel2.add(txtname);
		panel2.add(insert);
		panel2.add(lsp);
		panel2.add(txtsp);
		panel2.add(update);
		panel2.add(lip);
		panel2.add(txtip);
		panel2.add(delete);
		
		columnnames.add("ID");
		columnnames.add("Fullname");
		columnnames.add("Sell Price");
		columnnames.add("Indigrient Price");
		
		dtm = new DefaultTableModel(data, columnnames);
		table.setModel(dtm);
		
		pane.setViewportView(table);
		panel3.add(pane);
		
		add(panel1, BorderLayout.NORTH);
	    add(panel2, BorderLayout.CENTER);
	    add(panel3, BorderLayout.SOUTH);
	    
	    readData();
	}
	public ManageMenuForm() 
	{
		InitialComponent();
		Action();
;		InitialFrame();
	}
	
	public static void main(String[] args) 
	{
		new Main();
	}
	
	private void Action()
	{
		insert.addActionListener(new ActionListener()
		{
		public void actionPerformed(ActionEvent e) 
		{
			String name = txtname.getText();
			Integer sp = 0;
			Integer ip = 0;
			String id = "";
			Random r = new Random();
	        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwwxyz0123456789";
	        for(int i = 0; i<10; i++)
	        {
	        id += alphabet.charAt(r.nextInt(42));
	        }
	        try
	        {
	        	sp = Integer.parseInt(txtsp.getText());
	        	ip = Integer.parseInt(txtip.getText());
	        }
	        catch(Exception Exception)
	        {
	        	JOptionPane.showMessageDialog(null, "Prices must be Numeric !");
	        }
			if(name.length() == 0 ||sp == 0 || ip == 0)
			{
				JOptionPane.showMessageDialog(null, "All Field must be Filled");
			}
			else
			{	
				String query = "INSERT INTO menu(menuid, name, sellprice, ingredientprice) VALUES ('"+id+"','"+name+"',"+sp+","+ip+")";
				con.executeUpdate(query);
				readData();
			}
			
		}
		}
				);
		delete.addActionListener(new ActionListener()
		{
		public void actionPerformed(ActionEvent e) 
		{
			if(table.getSelectedRow() == 0)
			{
				JOptionPane.showMessageDialog(null, "please select data to be deleted first");
			}
			else 
			{
				String getId = dtm.getValueAt(table.getSelectedRow(), 0).toString();
				String query = "DELETE FROM menu WHERE menuid ='"+getId+"'";
				con.executeUpdate(query);
				readData();
			}
		}
		}
				);
		update.addActionListener(new ActionListener()
		{
		public void actionPerformed(ActionEvent e) 
		{
			String getId = dtm.getValueAt(table.getSelectedRow(), 0).toString();
			String name = txtname.getText();
			Integer sp = 0;
			Integer ip = 0;
	        try
	        {
	        	sp = Integer.parseInt(txtsp.getText());
	        	ip = Integer.parseInt(txtip.getText());
	        }
	        catch(Exception Exception)
	        {
	        	JOptionPane.showMessageDialog(null, "Prices must be Numeric !");
	        }
			if(name.length() == 0 ||sp == 0 || ip == 0)
			{
				JOptionPane.showMessageDialog(null, "All Field must be Filled");
			}
			else
			{	
				String query = "UPDATE menu SET name = '"+name+"', sellprice = "+sp+",ingredientprice = "+ip+" WHERE menuid ='"+getId+"'";
				con.executeUpdate(query);
				readData();
			}
			
		}
		}
				);
	}
	
	void readData()
	{
		String query = "SELECT * FROM menu";
		ResultSet rs = con.executeQuery(query);
		try
		{
			data.clear();
				while(rs.next())
				{
					String id = rs.getString(1);
					String name = rs.getString(2);
					Integer sp = rs.getInt(3);
					Integer ip = rs.getInt(4);
					
					Vector<String> vec = new Vector();
					
					vec.add(id);
					vec.add(name);
					vec.add(sp.toString());
					vec.add(ip.toString());
					
					data.add(vec);
				}
			}
			catch (SQLException Throwables)
			{
				Throwables.printStackTrace();
			}
			
			dtm.fireTableDataChanged();
		}
	}

